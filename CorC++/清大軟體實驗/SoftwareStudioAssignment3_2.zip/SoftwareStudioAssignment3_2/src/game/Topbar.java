package game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Stack;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Topbar extends JPanel{

	private Stack<JLabel> lives = new Stack<JLabel>();
	private int score = 0;
	
	
	public Topbar(Rectangle bounds, int lifecount) {
		/*TODO: Initialize the topbar*/
	}
	
	/*
	 * implement all labels and methods you need to do about "score" and "life"
	 */
	

}
