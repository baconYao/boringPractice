package model;

/**
 * This is the file doing pre-process for your input. You are ask to:
 * 1.Implement file input and load it into your data structure. 
 * 	ArrayList is recommend as the data structure for SentencePC and SentenceMP 
 * 2.A method that randomly choose a sentence in your data structure as the 
 * 	question 
 * 
 * */

import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Model {
	
	/*
	 * Hints for parsing input:
	 * 
	 * Using "split" method in String class to distribute inputed line.
	 * Use regular expression as a split method    
	 * String str = new String(); 
	 * str.split("[^-0-9]"); 	  // Get only the digits in the string.
	 * str.split("[^A-Za-z ]");   // Get numbers letter with a space in the string. 
	 * str.split("[A-Za-z0-9-]"); // Get anything in the string but keep letter, digit and '-' away
	 */
	

	/**
	 * private static String stringArrayToString(String[] str) For the return
	 * value of split is String[], turn String[] to String for better use
	 * 
	 * @input - String[] str - a String[]
	 * @return - String
	 */
	private static String stringArrayToString(String[] str) {
		String temp = null;
		for(String i: str) temp = i;
		return temp;
	}
		
}

